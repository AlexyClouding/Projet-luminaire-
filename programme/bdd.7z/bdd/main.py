import paho.mqtt.client as mqtt
import json as json
import base64
import mysql.connector
import time


#Création du client MQTT
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
#Username broker (intégration TTN) -> MDP broker (intégration TTN)
client.username_pw_set("projet-btsfourcade@ttn","NNSXS.TEHNECHZQ3MJQXCVB3RKOSGMPMNUTWRO2GZFRUI.AWERZSCJJVG2RIQMNTWCHXAQ4B7RNLCJWMFPK5ABCAOV2OQ43HPA")

connected = False
while not connected:
    try:
        # Connexion au broker TTN
        client.connect("eu1.cloud.thethings.network", 1883, 60)
        connected = True
        print("Connexion TTN établie")
    except Exception as e:
        print("Échec de la connexion")
        print("Nouvelle tentative de connexion dans 10 secondes...")
        time.sleep(10)  # Pause de 10 secondes avant la prochaine tentative


def connexionDB():
    while True:
        try:
            DataBase = mysql.connector.connect(host="10.10.10.16", user="technicien", password="luminaire123", database="Luminaire")
            db_Info = DataBase.get_server_info()
            print("Connected to MySQL Server version", db_Info)
            return DataBase  # Retourne la connexion à la base de données
        except mysql.connector.Error as err:
            print("Erreur de DB:", err)
            time.sleep(3)

DataBase = connexionDB()
Query = DataBase.cursor()

def RecupData(a,b,c,d,e):
    data = (a, b, c, d, e)
    ecriture(data)

def ecriture(data):
    print("-----------------")
    try:
        Query.execute("INSERT INTO Mesure (Temperature,EtatBatterie,CourantLed,EtatLed,LuminositeExterieur) VALUES(%s, %s, %s, %s, %s)",data)
        print("Valeurs (%s, %s, %s, %s, %s)",data)
        DataBase.commit()  # N'oubliez pas de valider la transaction
    except mysql.connector.Error as erreur:
        print("Erreur de requete : ", erreur)

def Receive(client, userdata, msg):
    resultat_complet = json.loads(msg.payload.decode())
    payload = resultat_complet['uplink_message']['frm_payload']
    print("Information reçu :", base64.b64decode(payload).decode())
    data=base64.b64decode(payload).decode()
    print(data)

    ###---- DEFINIR LA TRAME ET LA TRADUIRE-----------------------------------------------------------------------------------------------------------
    aa=1
    bb="okk"
    cc=3
    dd=4
    ee=5
    time.sleep(1)
    RecupData(aa,bb,cc,dd,ee)

#Query.execute("SELECT * FROM Mesure")
#rows = Query.fetchall()
#for row in rows:
#    print('{0} : {1} - {2} - {3} - {4} - {5}'.format(row[0], row[1], row[2], row[3], row[4], row[5]))

client.on_message = Receive
client.subscribe("#")
client.loop_forever()

#DataBase.close()
